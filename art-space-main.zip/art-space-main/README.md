# Art Space
Art Space - An app that displays some artwork made using Kotlin and Jetpack Compose

## App
```bash
app > release > app-release.apk
```

That's where the app is located
